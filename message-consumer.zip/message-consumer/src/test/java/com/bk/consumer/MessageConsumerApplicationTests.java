package com.bk.consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
