package com.bk.streaming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageStreamingApplicationTests {

	@Test
	void contextLoads() {
	}

}
